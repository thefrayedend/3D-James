---
name: 3djames-project
description: Save a 3D model as a 3DJames project (.json) that opens fully editable in the 3DJames CAD app, instead of a STEP/STL. Use when the user asks to export, save or build a model for 3DJames.
---

# Saving models as 3DJames projects

3DJames is a local parametric CAD app (3D Builder look, OpenCascade inside). A 3DJames `.json` project is not a mesh: it is the list of build steps (shapes, moves, merges, fillets...). When the user opens it, every step shows in **History** and stays editable (sizes, positions, variables). That is why this format beats STEP for anything you design: STEP only carries the finished solid.

Workflow:
1. Plan the model as primitives + steps (below). Put key sizes in `vars` so the user can change them later in one place.
2. Write the JSON file with a short Python script (no hand-typing huge files).
3. Run the checker at the bottom. Fix everything it reports.
4. Deliver: if the user's computer is linked, write it into the Projects folder next to their 3DJames.html (create it if needed); otherwise send the file. Tell them: open 3DJames, click **≡** (top left) > **Open…** (or Ctrl+O), pick the file. Save in 3DJames keeps it as a project.

If a model came from code (CadQuery, OpenSCAD, replicad), translate its operations into these steps. If a shape has no equivalent (custom 2D sketch, loft, sweep, spline), build it from primitives + subtract/intersect as closely as possible and tell the user which parts are approximated. If that is impossible, say so and offer STEP instead.

## Make it easy to edit (important)
People edit these files by hand. In 3DJames, selecting an object shows how it was made as a tree in History (its steps, with the shapes cut out of it or merged into it listed under each cut/merge), so the steps must read like a recipe, not a pile of parts.
- **Name every step** (`"name"` on every feature) and **every body specifically**: "Post 1 groove (front)", "Tray T2 M4 hole, rear left" — never just "slot", "hole", "strip". Someone scanning History must see what each cut is for.
- **Keep each object's steps together, in order**: its base shape, then its cutting/adding shapes, then the combine, then fillets. Finish one object before starting the next.
- **One cutter + array, not many copies.** Four identical grooves = one groove shape + `array` (or `mirror` copy), then one subtract. Then changing the groove once changes all of them.
- **Drive repeated sizes from `vars`** with clear names (`grooveW`, `grooveDepth`, `holeD`) so a change is one number.
- Prefer fewer, meaningful steps over many tiny ones. A model with hundreds of unnamed steps is not editable in practice even if it is technically parametric.

## Units and coordinates
- Millimetres. Z is up. The floor is Z = 0.
- A `shape` is built centred on X/Y with its **bottom at Z = 0**, then rotated (`rot`, degrees, about the shape's own centre, Euler order 'ZYX' — prefer single-axis rotations), then moved by `pos`.
- So `pos = [x_centre, y_centre, z_bottom]`.

## File layout
```json
{
  "v": 1, "name": "Space Pi rack", "seq": 200, "counters": {},
  "vars": [ {"name": "wall", "expr": "4"}, {"name": "pitch", "expr": "slotW + wall"} ],
  "bodies": { "b1": {"name": "Base", "color": "#56b866"},
              "b3": {"name": "Screw hole", "color": "#8b96a3", "hole": true} },
  "features": [ ...steps in build order... ]
}
```
- **Every body id used anywhere (`body`, `body2`, copy targets) needs an entry in `bodies`** with `name` and `color` — otherwise it shows up grey and unnamed.
- Ids: bodies `b1, b2...`, features `f1, f2...`, all unique. `seq` must be **larger than every number used in any id** (3DJames makes new ids from it).
- Any number field may be an expression string using `vars`: `"slots*pitch + wall"`. Operators `+ - * / % ^ ( )`, functions `sin cos tan` (degrees) `sqrt abs min max round floor ceil`, constant `pi`. Vars may use earlier vars.
- `"hole": true` on a body makes it a hole (grey, cuts when merged).
- 3D Builder colours: box `#56b866`, sphere `#2e8a44`, cylinder `#3d9ce0`, tetrahedron `#1b9ccd`, wedge `#3a74a6`, hexagon `#ffa940`, cone `#ee7a35`, torus `#f2e43c`, pyramid `#c9bc22`, tube `#dd3a3d`, hole `#8b96a3`.

## Shapes: `{"id","type":"shape","body","kind","p":{...},"pos":[x,y,z],"rot":[rx,ry,rz]}`
| kind | p (defaults) |
|---|---|
| box | `w` (X) 20, `d` (Y) 20, `h` (Z) 20, `round` 0, `roundMode` `all`/`vertical`/`top` |
| cyl | `d` 20, `h` 20 |
| sphere | `d` 20 |
| cone | `d1` bottom 20, `d2` top 0, `h` 20 |
| torus | `D` ring 24, `d` tube 6 |
| wedge | `w` (X) 20, `d` (Y) 20, `h` (Z) 20 |
| pyramid | `n` sides 4 (3 = tetrahedron), `d` base diameter 20, `h` 20 |
| tube | `od` 20, `id` 14, `h` 20 |
| prism | `n` sides 6 (hexagon), `af` width across flats 20, `h` 10 |
| text | `text`, `size` 10, `depth` 3, `font` `sans`/`round` |
| thread | `kind` `bolt`/`nut`/`cutter`, `size` e.g. `M8` (or `custom`), `D` 8, `P` 1.25, `len` 16, `clear` 0.15, `head` `hex`/`round`/`none`, `headH` 5.6, `af` 13, `nutH` 6.4, `chamfer` true |

Threads are meshes: anything merged with one becomes a mesh (no fillets/STEP after). Do threads last. For a threaded hole: a `thread` with `kind: "cutter"` in a body marked `hole`, then subtract it.
Sizes M2–M30, #6-32, #8-32, #10-24, 1/4"-20, 5/16"-18, 3/8"-16, 1/2"-13. Always give D, P, af, headH, nutH too (D/P from the standard; headH ≈ 0.7·D, nutH ≈ 0.8·D, af = hex size).

## Other steps
- **combine** `{"type":"combine","op":"union"|"subtract"|"intersect","body":"b1","tools":["b2","b3"]}` — result stays in `body`; tool bodies are used up (don't reference them later). In a union, tools marked `hole` are cut.
- **copy** `{"type":"copy","src":"b1","body":"b7","d":[dx,dy,dz]}` — new body `b7` (add it to `bodies`).
- **move** `{"type":"move","body":"b1","m":[16 numbers]}` — 4×4 column-major matrix (three.js order): plain shift = `[1,0,0,0, 0,1,0,0, 0,0,1,0, dx,dy,dz,1]`. For primitives, prefer editing `pos`/`rot` instead.
- **array** `{"type":"array","body":"b2","kind":"linear","n":4,"dx":64,"dy":0,"dz":0}` — n total copies (2–200), merged into the body. Circular: `"kind":"circular","n":6,"angle":360,"cx":0,"cy":0` (around a vertical axis).
- **mirror** `{"type":"mirror","body":"b1","axis":"x"|"y"|"z","copy":true,"side":"max"|"min"}` — `copy:true` adds a mirrored copy against that side of its bounding box (merged in); `copy:false` flips in place.
- **fillet / chamfer** `{"type":"fillet","body":"b1","edges":[{"nc":[1,0.5,1],"d":[0,1,0]}],"r":3}` — each edge: `nc` = edge midpoint as a 0–1 fraction of the body's bounding box *at that step*, `d` = edge direction. Example: on a box, the top edge along Y at the +X side is `nc [1,0.5,1]`, `d [0,1,0]`. Matches within 0.2 of the box size, so pick edges that are clearly distinct. For simple boxes prefer `round` + `roundMode`.
- **shell** (hollow) `{"type":"shell","body":"b1","faces":[{"nc":[0.5,0.5,1],"d":[0,0,1]}],"t":2}` — faces listed are removed (open top); `faces: []` hollows fully closed. Face ref: `nc` = face centre fraction, `d` = outward normal.
- **extrude** on a face `{"type":"extrude","body":"b1","face":{nc,d},"prof":"rect"|"circle"|"poly"|"slot","w":10,"h":10,"d":10,"n":6,"u":0,"v":0,"depth":5,"mode":"add"|"cut"}` — `u,v` offset from the face centre.
- **split** `{"type":"split","body":"b1","off":0,"roll":0,"pitch":0,"yaw":0,"keep":"above"|"below"|"both","body2":"b8"}` — plane through the body's centre, normal +Z rotated by roll/pitch/yaw degrees, shifted `off` along the normal. `body2` (needed for `both`) gets the upper part.
- **pushpull** `{"type":"pushpull","body":"b1","face":{nc,d},"d":5}` — moves a flat face along its normal: positive adds material, negative removes it.
- **delete** `{"type":"delete","body":"b5"}`.
- Any step may have `"name"` (shown in History) or `"suppressed": true`.

Positioning tip: when stacking (a wall on a base), overlap by 0.01 (`"pos":[x,y,"wall - 0.01"]`) so merges fuse cleanly.

## Checker (run before delivering)
```python
import json, re, sys, collections
d = json.load(open(sys.argv[1])); errs = []
KINDS = {'box','cyl','sphere','cone','torus','wedge','pyramid','tube','prism','text','thread'}
TYPES = {'shape','combine','copy','move','array','mirror','fillet','chamfer','shell','extrude','pushpull','split','delete'}
names = [v['name'] for v in d.get('vars', [])]
ids = [f['id'] for f in d['features']]
if len(ids) != len(set(ids)): errs.append('duplicate feature ids')
nums = [int(x[1:]) for x in ids + list(d['bodies']) if re.fullmatch(r'[bf]\d+', x)]
if nums and d.get('seq', 0) <= max(nums): errs.append(f"seq must be > {max(nums)}")
alive = set()
def expr(v, where):
    if isinstance(v, str):
        for w in re.findall(r'[A-Za-z_]\w*', v):
            if w not in names and w not in {'sin','cos','tan','sqrt','abs','min','max','round','floor','ceil','pi','PI'}: errs.append(f'{where}: unknown name {w}')
for f in d['features']:
    w = f"{f['id']} ({f['type']})"
    if f['type'] not in TYPES: errs.append(w + ': unknown type'); continue
    for k, v in f.items():
        if k == 'p':
            for kk, x in v.items():
                if kk in ('text','kind','head','font','roundMode') or (kk == 'size' and f.get('kind') == 'thread'): continue
                expr(x, w)
        elif k in ('pos','rot','d') and isinstance(v, list): [expr(x, w) for x in v]
        elif k in ('r','t','n','dx','dy','dz','off','roll','pitch','yaw','depth','angle','cx','cy','u','v','w','h'): expr(v, w)
    new = [f['body']] if f['type'] in ('shape','copy') else []
    if f['type'] == 'split' and f.get('keep') == 'both': new.append(f.get('body2'))
    if f['type'] == 'shape' and f.get('kind') not in KINDS: errs.append(w + ': unknown kind')
    if f['type'] == 'copy' and f['src'] not in alive: errs.append(w + f": {f['src']} not available")
    for b in [f['body']] + f.get('tools', []):
        if f['type'] not in ('shape','copy') and b not in alive: errs.append(w + f': {b} does not exist (yet) or was used up')
    for b in dict.fromkeys(new + [f['body']] + f.get('tools', [])):
        if b and b not in d['bodies']: errs.append(w + f': {b} missing from "bodies"')
    alive.update(b for b in new if b)
    if f['type'] == 'combine': alive.difference_update(f.get('tools', []))
    if f['type'] == 'delete': alive.discard(f['body'])
unnamed = [f['id'] for f in d['features'] if not f.get('name')]
if unnamed: errs.append(f"{len(unnamed)} steps have no name (e.g. {', '.join(unnamed[:5])})")
dup = [n for n, c in collections.Counter(b['name'] for b in d['bodies'].values()).items() if c > 1]
if dup: errs.append('body names used more than once, make them specific: ' + ', '.join(dup[:8]))
print('\n'.join(errs) or f"OK: {len(ids)} steps, {len(alive)} objects at the end")
```
The checker catches structure mistakes only. Geometry problems (a fillet too big, objects not touching) show in 3DJames as a red problem on that step in History, which can be clicked to edit. Ask the user to open the file and say whether anything is flagged.
